<?php
session_start();
include 'includes/config.php';
include 'includes/functions.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];
    $qty = $_POST['quantity'];
    $conn->query("INSERT INTO products (name, description, price, quantity) VALUES ('$name', '$desc', '$price', '$qty')");
}
if (isset($_GET['delete'])) {
    $conn->query("DELETE FROM products WHERE id=" . $_GET['delete']);
}
$products = $conn->query("SELECT * FROM products");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Admin</title>
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2>Panel de Administración</h2>
        <a href="logout.php">Cerrar sesión</a>
        <form method="POST">
            <input type="text" name="name" placeholder="Nombre del producto" required><br>
            <textarea name="description" placeholder="Descripción"></textarea><br>
            <input type="number" name="price" step="0.01" placeholder="Precio"><br>
            <input type="number" name="quantity" step="1" placeholder="Cantidad"><br>
            <button type="submit">Agregar Producto</button>
        </form>
        <hr>
        <h3>Productos</h3>
        <ul>
        <?php while ($row = $products->fetch_assoc()) { ?>
            <li>
                <strong><?= $row['name'] ?></strong> - <?= $row['description'] ?> - $<?= $row['price'] ?> - Cantidad: <?= $row['quantity'] ?>
                <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('¿Eliminar producto?')">Eliminar</a>
            </li>
        <?php } ?>
        </ul>
    </div>
</body>
</html>